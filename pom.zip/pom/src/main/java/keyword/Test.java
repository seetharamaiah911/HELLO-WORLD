package keyword;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

String value = "Renault (10057)";
		
		String[] val1 = value.split("\\(");
		
		String val = val1[0];
		System.out.println(val);
	}

}
