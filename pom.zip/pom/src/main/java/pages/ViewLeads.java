package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class ViewLeads extends LeafTapsWrappers  {

	public ViewLeads(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("View Lead | opentaps CRM")){
			reportStep("This is not View leads Page", "FAIL");
		}
	}
	
	public ViewLeads VerifyFname(String fname){
		verifyTextById("viewLead_firstName_sp", fname);
		return this;	
	}	
	
	public EditLeadPage ClickEditButton(){
		clickByXpath("//a[text()='Edit']");
		return new EditLeadPage(driver, test);
	}
	
	public ViewLeads VerifyTitle(){
		verifyTitle("View Lead | opentaps CRM");
		return this;
	}
	
	public ViewLeads VerifyCompanyname(){
		
		
		String value =getTextById("viewLead_companyName_sp");
		
	    String[] val1 = value.split("\\(");
		
		String val = val1[0];
		System.out.println(val);
		
		return this;
	}
	
	public MyLeadsPage ClickDelete(){
		clickByXpath("//a[@class='subMenuButtonDangerous']");
		return new MyLeadsPage(driver, test);
	}
	
	public DuplicateLead ClickDuplicateLead(){
		clickByLink("Duplicate Lead");
		return new DuplicateLead(driver, test);
	}
}
	
