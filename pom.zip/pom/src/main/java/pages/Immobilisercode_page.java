package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class Immobilisercode_page extends GCO_Wrappers  {

	public Immobilisercode_page(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

/*		if(!verifyTitle("antidemar")){
			reportStep("This is not Immobiliser code page", "FAIL");
		}
*/	}
	
	
	public Immobilisercode_page enterVIN(String VIN){
		moveToDefaultFrame();
   		moveToFrame("data");
   		//moveToFrame(code.frame.first);
   		moveToFrame("saisie");
   		enterByName("vin", VIN);
   		return this;
	}
	
	
	
	public Immobilisercode_page pk1to4(String data1to4){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part1", data1to4);
   		return this;
	}
	
	public Immobilisercode_page pk5to8(String data5to8){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part2", data5to8);
   		return this;
	}
	
	public Immobilisercode_page pk9to12(String data9to12){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part3", data9to12);
   		return this;
	}
	
	public Immobilisercode_page pk13to16(String data13to16){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part4", data13to16);
   		return this;
	}
	
	public Immobilisercode_page pk17to20(String data17to20){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part5", data17to20);
   		return this;
	}
	
	public Immobilisercode_page pk21to24(String data21to24){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part6", data21to24);
   		return this;
	}
	
	public Immobilisercode_page pk25to28(String data25to28){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part7", data25to28);
   		return this;
	}
	
	
	public Immobilisercode_page pk29to32(String data29to32){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part8", data29to32);
   		return this;
	}
	
	public Immobilisercode_page pk33to36(String data33to36){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part9", data33to36);
   		return this;
	}
	
	public Immobilisercode_page pk37to40(String data37to40){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("part10", data37to40);
   		return this;
	}
	/*enterByName("part1", "1234");
		enterByName("part2", "1234");
		enterByName("part3", "1234");
		enterByName("part4", "1234");
		enterByName("part5", "1234");
		enterByName("part6", "123");*/
	
	public Immobilisercode_page submitButton(){
		moveToDefaultFrame();
		moveToFrame("data");
		moveToFrame("saisie");
		clickByName("submit_btn");
		return this;
	}
	
	
	
	public void verifyOutput(String xpath,String text){
		moveToDefaultFrame();
		moveToFrame("data");
		moveToFrame("reponse");
		//verifyTextByXpath("//p[contains(text(),'The VIN must be made up of 17 characters. Do not enter any spaces.')][@class='gdcredinfo']", "The VIN must be made up of 17 characters. Do not enter any spaces.");
	    verifyTextContainsByXpath(xpath, text);
	}
	
	
	
	
	
	

}
