package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class APPRENTISSAGEAVECDDT2000page extends GCO_Wrappers  {

	public APPRENTISSAGEAVECDDT2000page(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

/*		if(!verifyTitle("antidemar")){
			reportStep("This is not Immobiliser code page", "FAIL");
		}
*/	}
	
	
	public APPRENTISSAGEAVECDDT2000page enterVIN(String VIN){
		moveToDefaultFrame();
   		moveToFrame("data");
   		//moveToFrame(code.frame.first);
   		moveToFrame("saisie");
   		enterByName("vin", VIN);
   		return this;
	}
	
	public  APPRENTISSAGEAVECDDT2000page enterEntreeserveur(String ense){
		moveToDefaultFrame();
   		moveToFrame("data");
   		//moveToFrame(code.frame.first);
   		moveToFrame("saisie");
   		enterByName("entreeserveur", ense);
   		return this;
	}
	
	public APPRENTISSAGEAVECDDT2000page codeAPV(String CodeAPV1){
		moveToDefaultFrame();
   		moveToFrame("data");
   		//moveToFrame(code.frame.first);
   		moveToFrame("saisie");
   		enterByName("codeapv", CodeAPV1);
   		return this;
	}

	
		
	public APPRENTISSAGEAVECDDT2000page submitButton(){
		moveToDefaultFrame();
		moveToFrame("data");
		moveToFrame("saisie");
		clickByXpath("/html/body/center/form/table/tbody/tr[6]/td[2]/input");
		return this;
	}
	
	
	
	public void verifyOutput(String xpath,String text) throws InterruptedException{
		Thread.sleep(3000);
		moveToDefaultFrame();
		moveToFrame("data");
		moveToFrame("reponse");
		//verifyTextByXpath("//p[contains(text(),'The VIN must be made up of 17 characters. Do not enter any spaces.')][@class='gdcredinfo']", "The VIN must be made up of 17 characters. Do not enter any spaces.");
	    verifyTextByXpath(xpath, text);
	    
	}
	
	
	
	
	
	

}
