package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class Returnoftoolreprogrammingkeypage extends GCO_Wrappers  {

	public Returnoftoolreprogrammingkeypage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

/*		if(!verifyTitle("antidemar")){
			reportStep("This is not Immobiliser code page", "FAIL");
		}
*/	}
	
	
	public Returnoftoolreprogrammingkeypage enterVIN(String VIN){
		moveToDefaultFrame();
   		moveToFrame("data");
   		//moveToFrame(code.frame.first);
   		moveToFrame("saisie");
   		enterByName("vin", VIN);
   		return this;
	}
	
	
	
	public Returnoftoolreprogrammingkeypage precode(String Precodedata){
		moveToDefaultFrame();
   		moveToFrame("data");
   		moveToFrame("saisie");
   		enterByName("precode", Precodedata);
   		return this;
	}
	
	public Returnoftoolreprogrammingkeypage submitButton(){
		moveToDefaultFrame();
		moveToFrame("data");
		moveToFrame("saisie");
		clickByName("submit");
		return this;
	}
	
	
	
	public void verifyOutput(String xpath,String text){
		moveToDefaultFrame();
		moveToFrame("data");
		moveToFrame("reponse");
		//verifyTextByXpath("//p[contains(text(),'The VIN must be made up of 17 characters. Do not enter any spaces.')][@class='gdcredinfo']", "The VIN must be made up of 17 characters. Do not enter any spaces.");
	    verifyTextContainsByXpath(xpath, text);
	}
	
	
	
	
	
	

}
