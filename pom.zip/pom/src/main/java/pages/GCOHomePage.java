package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.gargoylesoftware.htmlunit.javascript.host.dom.RadioNodeList;
import com.relevantcodes.extentreports.ExtentTest;

import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class GCOHomePage extends GCO_Wrappers  {

	public GCOHomePage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

	/*	if(!verifyTitle("Menu")){
			reportStep("This is not HOME  page", "FAIL");
		}*/
	}
	
	public Immobilisercode_page clickLinkIM(String Description) throws InterruptedException{
		Thread.sleep(3000);
		System.out.println(Description);
		reportStep(Description,"Pass");
		moveToFrame("data");
		clickByLink("Retrieval of the immobiliser code");
		return new Immobilisercode_page(driver, test);
	}
		
	public CarRadioCodepage clickLinkRadioCode(String Description) throws InterruptedException{
		Thread.sleep(3000);
		System.out.println(Description);
		reportStep(Description,"Pass");
		moveToFrame("data");
		clickByLink("Retrieval of the car radio code");
		return new CarRadioCodepage(driver, test);
	}
	
	public Returnoftoolreprogrammingkeypage clickLinkReturnOfToolReprogrammingkey(String Description) throws InterruptedException{
		Thread.sleep(3000);
		System.out.println(Description);
		reportStep(Description,"Pass");
		moveToFrame("data");
		clickByLink("Return of tool reprogramming key");
		return new Returnoftoolreprogrammingkeypage(driver, test);
	}
	
	public RetrievalOfTheEntertainmentSystemCodepage clickLinkRetrievalOfTheEntertainmentSystemCode(String Description) throws InterruptedException{
		Thread.sleep(3000);
		System.out.println(Description);
		reportStep(Description,"Pass");
		moveToFrame("data");
		clickByLink("Retrieval of the entertainment system code");
		return new RetrievalOfTheEntertainmentSystemCodepage(driver, test);
	}
	
	public RetrievalOfTheOscarBoxCodePage clickLinkRetrievalOfTheOscarBoxCode(String Description) throws InterruptedException{
		Thread.sleep(3000);
		System.out.println(Description);
		reportStep(Description,"Pass");
		moveToFrame("data");
		clickByLink("Retrieval of the Oscar box code");
		return new RetrievalOfTheOscarBoxCodePage(driver, test);
	}
	
	public APPRENTISSAGEAVECDDT2000page APPRENTISSAGEAVECDDT2000(String Description) throws InterruptedException{
		Thread.sleep(3000);
		System.out.println(Description);
		reportStep(Description,"Pass");
		moveToFrame("data");
		clickByLink("Apprentissage DDT2000");
		return new APPRENTISSAGEAVECDDT2000page(driver, test);
	}

}
