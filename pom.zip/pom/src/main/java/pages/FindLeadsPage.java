package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class FindLeadsPage extends LeafTapsWrappers{

	public FindLeadsPage(RemoteWebDriver driver, ExtentTest test) {
		
		// TODO Auto-generated constructor stub
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Find Leads | opentaps CRM")){
			reportStep("This is not FindLeads Page", "FAIL");
	}

	}
	
	public FindLeadsPage EnterFirstName(String FirstName) {
		enterByXpath("(//input[@type='text' and @name='firstName'])[3]", FirstName);
		return this;
		
	}
	
	public FindLeadsPage ClickFindLeadsButton(){
		clickByXpath("//button[contains(text(),'Find Leads')]");
		return this;
	}
	
	public ViewLeads ClickOnFirstResultingLead(){
		clickByXpath("//td[@style='width:139px;']//div[@class='x-grid3-cell-inner x-grid3-col-firstName']");
		return new ViewLeads(driver, test);
	}
	
	
	public FindLeadsPage ClickOnPhone(){
     clickByXpath("//span[contains(text(),'Phone')]");
     return this;
	}

	public FindLeadsPage EnterPhoneNumber(String phonenumber) throws InterruptedException{
		Thread.sleep(3000);
			enterByXpath("//div[@style='padding: 0px 2px 0px 0px;']//input[@name='phoneNumber']",phonenumber);
			return this;
	}
	
	
	public FindLeadsPage CaptureLeadID(){
		String captureleadid = getTextByXpath("//td[@style='width:139px;']//div[@class='x-grid3-cell-inner x-grid3-col-partyId']");
		System.out.println("lead ID of First Resulting lead"+captureleadid+" ");
		return this;
		}
		
	public ViewLeads ClickFirstResultingLead(){
			clickByXpath("//td[@style='width:139px;']//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a[@class='linktext']");
			return new ViewLeads(driver, test);
		}
	public FindLeadsPage EnterCapturedLeadID(String captureleadid){
		enterByXpath("//div[@class='x-form-item x-tab-item']//div[@style='padding-left:155px']//input[@style='width: 212px;']", captureleadid);
		return this;
	}
		
	public FindLeadsPage ClickOnEmail(){
		clickByXpath("//span[contains(text(),'Email')]");
		return this;
	}
	
	public FindLeadsPage Enteremail(String data){
		enterByName("emailAddress", data);
	return this;
	}
	
	public FindLeadsPage Capturename(){
		String capturename = getTextByXpath("//td[@style='width:139px;']//div[@class='x-grid3-cell-inner x-grid3-col-firstName']");
		System.out.println("lead ID of First Resulting lead"+capturename+" ");
		return this;
	}
	
	public void EnterLeadId(){
		
	}



}
