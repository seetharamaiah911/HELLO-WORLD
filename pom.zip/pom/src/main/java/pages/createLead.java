package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class createLead extends LeafTapsWrappers{

	public createLead(RemoteWebDriver driver, ExtentTest test) {
		
		// TODO Auto-generated constructor stub
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Create Lead | opentaps CRM")){
			reportStep("This is not MyLeads Page", "FAIL");
	}

	}
	
	public createLead enterCompName(String compName) {
		enterById("createLeadForm_companyName", compName);
		return this;
		
	}
	
	public createLead enterFirstName(String firstName) {
		enterById("createLeadForm_firstName", firstName);
		return this;
	}
	
	public createLead enterLastName(String LastName) {
		enterById("createLeadForm_lastName", LastName);
		return this;
	}
	
	public createLead enterphonenumber(String data){
		enterById("createLeadForm_primaryPhoneNumber", data);
		return this;
	}
	
	public createLead entermailid(String data){
		enterById("createLeadForm_primaryEmail", data);
	return this;
	}
	
	public ViewLeads clickCreateLead() {
		clickByName("submitButton");
		return new ViewLeads(driver, test);
	}
	
}
