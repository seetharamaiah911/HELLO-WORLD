package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class MergeLeadsPage extends LeafTapsWrappers  {

	public MergeLeadsPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("Merge Leads | opentaps CRM")){
			reportStep("This is not Merge lead Page", "FAIL");
		}
	}
	public MergeLeadsPage ClickOnIconNearFromLead(){
		clickByXpath("//table[@id = 'widget_ComboBox_partyIdFrom']/following-sibling::a");
		return this;
	}
	
	public FindLeadsPage movetoFindLeadWindow(){
	switchToLastWindow();
	return new FindLeadsPage(driver, test);
	}
	
}