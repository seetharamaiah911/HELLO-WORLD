package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.LeafTapsWrappers;

public class EditLeadPage extends LeafTapsWrappers  {

	public EditLeadPage(RemoteWebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;

		if(!verifyTitle("opentaps CRM")){
			reportStep("This is not opentaps CRM(Edit) Page", "FAIL");
		}
	}
	
	public EditLeadPage ChangeTheCompanyName(String CompanyName){
		enterById("updateLeadForm_companyName",CompanyName);
		return this;
	}

	public ViewLeads ClickUpdate(){
		clickByXpath("//input[@value='Update']");
		return new ViewLeads(driver, test);
	}
}
