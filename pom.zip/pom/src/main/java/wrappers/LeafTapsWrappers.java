package wrappers;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import utils.DataInputProvider;

public class LeafTapsWrappers extends GenericWrappers {
	
	public String browserName;
	public String dataSheetName;
	
	

	@BeforeSuite
	public void beforeSuite(){
		startResult();
	}

	@BeforeTest
	public void beforeTest(){
		loadObjects();
	}
	
	@BeforeMethod
	public void beforeMethod() throws InterruptedException{
		test = startTestCase(testCaseName, testDescription);
		test.assignCategory(category);
		test.assignAuthor(authors);
		invokeApp(browserName);
		
	}
		
	@AfterSuite
	public void afterSuite(){
		endResult();
	}

	@AfterTest
	public void afterTest(){
		unloadObjects();
	}
	
	@AfterMethod
	public void afterMethod(){
		endTestcase();
		quitBrowser();
		
	}
	
	@DataProvider(name="fetchData")
	public Object[][] getData(){
		return DataInputProvider.getSheet(dataSheetName);		
	}	
	
	 public  void VerifyLogin(String browser, boolean bRemote) throws InterruptedException {
			
		    DesiredCapabilities dc = new DesiredCapabilities();
			dc.setBrowserName(browser);
			dc.setPlatform(Platform.WINDOWS);
	
		 
			if(browser.equalsIgnoreCase("INTERNETEXPLORER"))
			{
		 System.setProperty("webdriver.ie.driver", "d:/LocalData/z010793/Desktop/Test leaf/IE driver/IE32/IEDriverServer.exe");
			 driver =new InternetExplorerDriver();
			}
			String baseUrl1 = "http://su416ars.mc2.renault.fr:20051/gco/ctrl/login";
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			try 
			{
				
					
				driver.navigate().refresh();
				driver.get(baseUrl1);
				Runtime.getRuntime().exec("d:\\LocalData\\z010793\\Desktop\\Test leaf\\login.exe");
				Thread.sleep(500);				
				takeSnap();
				System.out.println("Browser opened successfully");
				Reporter.log("Browser opened successfully \n ");
				reportStep("The browser: launched successfully", "PASS");
			} 
			catch (UnhandledAlertException uae) 
			{
				driver.navigate().refresh();
				uae.printStackTrace();
				System.out.println("Failed in Unhandled Exception");
				reportStep("The browser: could not be launched", "FAIL");
			} 
			catch (Exception e) 
			{
				System.out.println("Failed on exeception");
			}
		
		}
     
	 public  void VerifyLogin(String browser) throws InterruptedException{
		 VerifyLogin(browser, false);
	 }
	 
	 
	 public void invokeApp(String browser, boolean bRemote) {
		 
		 String baseUrl1 = "http://vm954ars.mc2.renault.fr:4658/gco/ctrl/login";
			try {

				DesiredCapabilities dc = new DesiredCapabilities();
				dc.setBrowserName(browser);
				dc.setPlatform(Platform.WINDOWS);

				// this is for grid run
				if(bRemote)
					driver = new RemoteWebDriver(new URL("http://"+sHubUrl+":"+sHubPort+"/wd/hub"), dc);
				else{ // this is for local run
					if(browser.equalsIgnoreCase("chrome")){
						System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
						driver = new ChromeDriver();
					}else{
						System.setProperty("webdriver.ie.driver", "d:/LocalData/z010793/Desktop/Test leaf/IE driver/IE32/IEDriverServer.exe");
						driver =new InternetExplorerDriver();
					}
					
					
				}
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                
				try 
				{
					driver.navigate().refresh();
					driver.get(baseUrl1);
					Runtime.getRuntime().exec("d:\\LocalData\\z010793\\Desktop\\Test leaf\\login.exe");
					Thread.sleep(1000);
					
				} 
				catch (UnhandledAlertException uae) 
				{
					driver.navigate().refresh();
					uae.printStackTrace();
					System.out.println("Failed in Unhandled Exception");
					
				} 
				catch (Exception e) 
				{
					System.out.println("Failed on exeception");
				}
				
				
				
				

				primaryWindowHandle = driver.getWindowHandle();		
				reportStep("The browser:" + browser + " launched successfully", "PASS");

			} catch (Exception e) {
				e.printStackTrace();
				reportStep("The browser:" + browser + " could not be launched", "FAIL");
			}
		}

}






