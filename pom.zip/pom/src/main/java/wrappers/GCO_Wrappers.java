package wrappers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Reporter;

public class GCO_Wrappers extends LeafTapsWrappers{
	

	
	public void moveToDefaultFrame(){
		driver.switchTo().defaultContent();
		System.out.println("Focus is moved to Default Frame");
		Reporter.log("Focus is moved to Default Frame");
	}

	
	public void moveToFrame(String frame){
		driver.switchTo().frame(frame);
		System.out.println("Focus is on "+frame+" ");
		Reporter.log("Focus is on "+frame+" ");
	}	
	
	
   
	
	
}
