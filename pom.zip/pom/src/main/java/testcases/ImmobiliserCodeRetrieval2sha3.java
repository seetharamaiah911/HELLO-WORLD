package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.GCOHomePage;
import pages.Immobilisercode_page;
import pages.LoginPage;
import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class ImmobiliserCodeRetrieval2sha3 extends GCO_Wrappers {
	
	@BeforeClass
	public void setData() {
		testCaseName="IMCODE Error Messages";
		testDescription="IMCODE Error Messages";
		browserName="INTERNETEXPLORER";
		dataSheetName="IMCODE Error Messages";
		//category="Success scenarios";
		//category="IMCODE Error Messages";
		category="IMCODE Error Messages";
		authors="Seetharamaiah";
	}

	@Test(dataProvider="fetchData")
	public void im(String Description,String VIN,String data1to4,String xpath,String text) throws InterruptedException{

		new GCOHomePage(driver, test)
		.clickLinkIM(Description)
		.enterVIN(VIN)
		.pk1to4(data1to4)
		.submitButton()
		.verifyOutput(xpath, text);

	}

	
	

}
