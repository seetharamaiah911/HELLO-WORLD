package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class CreateLead extends LeafTapsWrappers {
	
	@BeforeClass
	public void setData() {
		testCaseName="Create lead";
		testDescription="POM practice";
		browserName="chrome";
		dataSheetName="CreateLead";
		category="Smoke";
		authors="KaSeeLax";
	}

	@Test(dataProvider="fetchData")
	public void createlead(String userName, String passWord,
			String compName, String firstName, String LastName, String phonenumber,String mailid,String fname ){

		new LoginPage(driver, test)
		.enterUserName(userName)
		.enterPassword(passWord)
		.clickLogin()
		.clickCRMSFA()
		.ClickLeads()
		.ClickCreateLead()
		.enterCompName(compName)
		.enterFirstName(firstName)
		.enterLastName(LastName)
		.enterphonenumber(phonenumber)
		.entermailid(mailid)
		.clickCreateLead()
		.VerifyFname(fname);
		
		
		
		

	}

	
	

}
