package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.GCOHomePage;
import pages.Immobilisercode_page;
import pages.LoginPage;
import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class ImmobiliserCodeRetrieval extends GCO_Wrappers {
	
	@BeforeClass
	public void setData() {
		testCaseName="IMCODE Error Messages";
		testDescription="IMCODE Error Messages";
		browserName="INTERNETEXPLORER";
		dataSheetName="IMCODE Error Messages";
		//category="Success scenarios";
		//category="IMCODE Error Messages";
		category="IMCODE Error Messages";
		authors="Seetharamaiah";
	}

	@Test(dataProvider="fetchData")
	public void im(String Description,String VIN,String data1to4,String data5to8,String data9to12,String data13to16,
			String data17to20,String data21to24,String data25to28,String data29to32,String data33to36,String data37to40,String xpath,String text) throws InterruptedException{

		new GCOHomePage(driver, test)
		.clickLinkIM(Description)
		.enterVIN(VIN)
		.pk1to4(data1to4)
		.pk5to8(data5to8)
		.pk9to12(data9to12)
		.pk13to16(data13to16)
		.pk17to20(data17to20)
		.pk21to24(data21to24)
		.pk25to28(data25to28)
		.pk29to32(data29to32)
		.pk33to36(data33to36)
		.pk37to40(data37to40)
		.submitButton()
		.verifyOutput(xpath, text);
		

	}

	
	
}
