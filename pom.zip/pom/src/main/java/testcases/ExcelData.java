package testcases;

import java.io.File;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ExcelData {
	@Test
	public void Inputdata() throws Exception, IOException {

		// Read Worksheet

		XSSFWorkbook wrkbk = new XSSFWorkbook(new File("./data/TC003.xlsx"));

		// Read Sheet

		XSSFSheet sheet1 = wrkbk.getSheet("Sheet1");

		// Read row

		int rowCount = sheet1.getLastRowNum();
		
		// Read column and last cell 
		
		int colCount = sheet1.getRow(0).getLastCellNum();
		
		//loop until row count

		for (int i = 1; i <= rowCount; i++) {

			XSSFRow row1 = sheet1.getRow(i);
			
		//loop until column count

		for (int j = 0; j < colCount; j++) {
			XSSFCell col1 = row1.getCell(j);
			System.out.println(col1.getStringCellValue());
			}
		}

		wrkbk.close();

	}

}
