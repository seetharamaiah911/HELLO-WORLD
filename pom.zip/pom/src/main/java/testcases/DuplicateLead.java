package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class DuplicateLead extends LeafTapsWrappers {
	
	@BeforeClass
	public void setData() {
		testCaseName="Duplicate lead";
		testDescription="POM practice";
		browserName="chrome";
		dataSheetName="DuplicateLead";
		category="Regression";
		authors="Seetharamaiah";
	}
	@Test(dataProvider="fetchData")
   public void editLead(String username,String password,String email){
	
	new LoginPage(driver, test)
	.enterUserName(username)
	.enterPassword(password)
	.clickLogin()
	.clickCRMSFA()
	.ClickLeads()
	.ClickFindLeads()
	.ClickOnEmail()
	.Enteremail(email)
	.ClickFindLeadsButton()
	.Capturename()
	.ClickFirstResultingLead()
	.ClickDuplicateLead();
	
	
}
}