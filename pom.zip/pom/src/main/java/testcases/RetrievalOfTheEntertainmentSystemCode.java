package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.GCOHomePage;
import pages.Immobilisercode_page;
import pages.LoginPage;
import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class RetrievalOfTheEntertainmentSystemCode extends GCO_Wrappers {
	
	@BeforeClass
	public void setData() {
		testCaseName="EntertainmentSystemCode";
		testDescription="EntertainmentSystemCode";
		browserName="INTERNETEXPLORER";
		dataSheetName="EntertainmentSystemCode error messsages";
		//category="Success scenarios";
		//category="IMCODE Error Messages";
		category="EntertainmentSystemCode error messages";
		authors="Seetharamaiah";
	}

	@Test(dataProvider="fetchData")
	public void radiocode(String Description,String VIN,String Precodedata,String xpath,String text) throws InterruptedException{

		new GCOHomePage(driver, test)
		.clickLinkRetrievalOfTheEntertainmentSystemCode(Description)
		.enterVIN(VIN)
		.precode(Precodedata)
		.submitButton()
		.verifyOutput(xpath, text);
		

	}

	
	
}
