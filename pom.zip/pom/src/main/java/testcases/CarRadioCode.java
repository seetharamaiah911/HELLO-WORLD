package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.GCOHomePage;
import pages.Immobilisercode_page;
import pages.LoginPage;
import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class CarRadioCode extends GCO_Wrappers {
	
	@BeforeClass
	public void setData() {
		testCaseName="Radio code";
		testDescription="Radio Code data";
		browserName="INTERNETEXPLORER";
		dataSheetName="Radio Code error messsages";
		//category="Success scenarios";
		//category="IMCODE Error Messages";
		category="Radio Code error messages";
		authors="Seetharamaiah";
	}

	@Test(dataProvider="fetchData")
	public void radiocode(String Description,String VIN,String Precodedata,String xpath,String text) throws InterruptedException{

		new GCOHomePage(driver, test)
		.clickLinkRadioCode(Description)
		.enterVIN(VIN)
		.precode(Precodedata)
		.submitButton()
		.verifyOutput(xpath, text);
		

	}

	
	
}
