package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.GCOHomePage;
import pages.Immobilisercode_page;
import pages.LoginPage;
import wrappers.GCO_Wrappers;
import wrappers.LeafTapsWrappers;

public class APPRENTISSAGEAVECDDT2000 extends GCO_Wrappers {
	
	@BeforeClass
	public void setData() {
		testCaseName="APPRENTISSAGE AVEC DDT 2000 ";
		testDescription="APPRENTISSAGE AVEC DDT 2000";
		browserName="INTERNETEXPLORER";
		dataSheetName="APPRENTISSAGE AVEC DDT 2000 messages";
		//category="Success scenarios";
		//category="IMCODE Error Messages";
		category="APPRENTISSAGE AVEC DDT 2000 messages";
		authors="Seetharamaiah";
	}

	@Test(dataProvider="fetchData")
	public void radiocode(String Description,String VIN,String ense,String CodeAPV1,String xpath,String text) throws InterruptedException{

		new GCOHomePage(driver, test)
		.APPRENTISSAGEAVECDDT2000(Description)
		.enterVIN(VIN)
		.enterEntreeserveur(ense)
		.codeAPV(CodeAPV1)
		.submitButton()
		.verifyOutput(xpath, text);

	}

	
	
}
