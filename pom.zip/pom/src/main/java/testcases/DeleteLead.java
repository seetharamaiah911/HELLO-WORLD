package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.LeafTapsWrappers;

public class DeleteLead extends LeafTapsWrappers {
	
	@BeforeClass
	public void setData() {
		testCaseName="Delete lead";
		testDescription="POM practice";
		browserName="chrome";
		dataSheetName="DeleteLead";
		category="smoke";
		authors="Seetharamaiah";
	}
	@Test(dataProvider="fetchData")
   public void editLead(String username,String password,String phonenumber) throws InterruptedException{
	
	new LoginPage(driver, test)
	.enterUserName(username)
	.enterPassword(password)
	.clickLogin()
	.clickCRMSFA()
	.ClickLeads()
	.ClickFindLeads()
	.ClickOnPhone()
	.EnterPhoneNumber(phonenumber)
	.ClickFindLeadsButton()
	.CaptureLeadID()
	.ClickOnFirstResultingLead()
	.ClickDelete();
	
	
	
	
	}
}
